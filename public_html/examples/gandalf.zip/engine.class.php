<?php
/**
 *
 * Silnik aplikacji
 *
 * @author Jakub Luczynski jakub.luczynski@gmail.com
 *
 * @version 3.0.0
 * @copyright (c) 2009 - 2010 Ksiegarnia Internetowa Gandalf, http://www.gandalf.com.pl/
 *
 */
?>
<?php
class Engine
{
    /*
    // Deklaracje pol klasy
    */

    
    private static $_aLoadedClasses;        // tablica-lista zaladowanych klas
    private static $_aLoadedElements;       // tablisa-lista zaladowanych elementow

    public static $oDBShop = NULL;          // obiekt bazy danych sklepu
    public static $oDBForum = NULL;         // obiekt bazy danych sklepu
    public static $aDebugData = array();    // tablica z danymi do debugu, dodawanymi recznie w programie (np w modelach)
    
    public static $aTimer = array();        // tablica z czasami generacji poszczegolnych elementow programu

    
    /*
    // Konstruktor i destruktor
    */
    
    
    public function __construct($p_sTarget = 'HTML')
    {
        $sTarget = trim((string)($p_sTarget));
        
        $this->_loadConfig();                                // zaladowanie konfiguracji
        $this->_loadCore();                                  // wgranie wymaganych klas
        
        Timer::start();                                      // uruchomienie czasomierza
        
        Error::singleton();                                  // obsluga bledow Error

        Cache::singleton();                                  // obsluga cache (APC, Memcached, etc)

        Session::singleton();                                // obsluga sesji
        
        Db::singleton();
        
        Db::$Shop = new DbMysql(                             // obsluga bazy danych sklepu - master
                Config::DBSHOP_DbHost,
                Config::DBSHOP_DbPort,
                Config::DBSHOP_DbName,
                Config::DBSHOP_DbUser,
                Config::DBSHOP_DbPass,
                Config::DBSHOP_DbCharset,
                Config::DBSHOP_DbNames,
                Config::DBSHOP_DbTimezone
                );
        
        Db::$Slave = new DbMysql(                            // obsluga bazy danych sklepu - aktualny serwer
                Config::DBSLV_DbHost,
                Config::DBSLV_DbPort,
                Config::DBSLV_DbName,
                Config::DBSLV_DbUser,
                Config::DBSLV_DbPass,
                Config::DBSLV_DbCharset,
                Config::DBSLV_DbNames,
                Config::DBSLV_DbTimezone
                );
        
        Db::$Forum = new DbMysql(                            // obsluga bazy danych forum
                Config::DBFORUM_DbHost,
                Config::DBFORUM_DbPort,
                Config::DBFORUM_DbName,
                Config::DBFORUM_DbUser,
                Config::DBFORUM_DbPass,
                Config::DBFORUM_DbCharset,
                Config::DBFORUM_DbNames,
                Config::DBFORUM_DbTimezone
                );
        
        Dictionary::singleton();                             // inicjalizacja slownika
        
        switch($sTarget)
        {
            case 'WWW': // site www
                $this->_initWWW();
                break;
                
            case 'CRON':
                $this->_initCron();
                break;
        }
    }

    public function __destruct()
    {
        global $iMemoryStart;

        $fTime = Timer::display();
        $this->_saveStats($fTime);
        
        Form::storeErrors();
        
        if (Config::DEBUG_Program === TRUE && Config::$bShowDebug === TRUE)
        {
            $fCCTime = ((isset(self::$aTimer['config+core'])) ? self::$aTimer['config+core'] : 0);
            
            // zapisujemy staty generacji
            if (Config::CACHE_Enabled == FALSE || Config::CACHE_Engine == 'INTERNAL')
            {
                $sQueryInsert = "INSERT INTO ___tmp_generation_time (url, internal_time, internal_counter) VALUES (?,?,?) ON DUPLICATE KEY UPDATE internal_time = internal_time + ?, internal_counter = internal_counter + 1";
                $sQuerySelect = "SELECT internal_time/internal_counter FROM ___tmp_generation_time WHERE url=?";
            }
            else if (Config::CACHE_Enabled == TRUE || Config::CACHE_Engine == 'APC')
            {
                $sQueryInsert = "INSERT INTO ___tmp_generation_time (url, apc_time, apc_counter) VALUES (?,?,?) ON DUPLICATE KEY UPDATE apc_time = apc_time + ?, apc_counter = apc_counter + 1";
                $sQuerySelect = "SELECT apc_time/apc_counter FROM ___tmp_generation_time WHERE url=?";
            }
            Db::$Shop->sqlTransactionBegin();
            Db::$Shop->sqlExec($sQueryInsert, array(Router::$sFullAdress, ($fTime + $fCCTime), 1, ($fTime + $fCCTime)));
            Db::$Shop->sqlTransactionCommit();

            $aIncludedFiles = get_included_files(); sort($aIncludedFiles);
            
            $sDebug = '<hr/>'
                .'<span style="color:red;font-size:14px;font-weight:bold;">DEBUG</span><br/>'
                .'<div id="debugd" style="height:350px; width:100%; overflow:scroll; font:12px verdana;">'
                .'<pre>'
                .htmlspecialchars(
                        print_r(
                            array(
                                //'objects' => array(self::$oDBShop),
                                'wersja php' => phpversion(),
                                'wgrane pliki' => $aIncludedFiles,
                                'wgrane css i js' => array(HtmlView::$sCss, HtmlView::$sJs),
                                'cache' => ((Config::CACHE_Enabled) ? Cache::getInfo() : 'no cache'),
                                //'cache keys' => Cache::$aKeys,
                                'konfiguracja' => Config::$aCfg,
                                'dane serwera' => $_SERVER,
                                'POST' => (isset($_POST) ? $_POST : 'brak'),
                                'FORM Data' => Form::$aFormData,
                                'FORM Error' => Form::$aFormError,
                                'GET' => (isset($_GET) ? $_GET : 'brak'),
                                'SESSION' => $_SESSION,
                                'Router FullAddress' => array(Router::$sFullAdress),
                                'Router Address' => array(Router::$aAddress),
                                //'Router Map' => Router::$aMapById,
                                'Router TemplateData' => Router::$aTemplateData,
                                'wgrane obiekty' => self::$_aLoadedClasses,
                                //'queries' => self::$oDBShop->getQueriesHistory(),
                                'queries gandalf' => Db::$Shop->getQueriesHistory(),
                                'queries gandalf slave' => Db::$Slave->getQueriesHistory(),
                                //'queries forum' => Db::$Forum->getQueriesHistory(),
                                'program timer' => self::$aTimer,
                                //'debug' => debug_backtrace(),
                                'reczne' => self::$aDebugData,
                                //'ilosc elementow' => ElementView::$iObjectCounter, // uruchamiac tylko w potrzebie, gdyz z crona wywala bledy bo nie ma deklaracji klasy
                                'pamiec start' => Lib::sizer($iMemoryStart),
                                'pamiec end' => Lib::sizer(memory_get_peak_usage()),
                                'pamiec zuzyta' => Lib::sizer(memory_get_peak_usage() - $iMemoryStart),
                                'czas generacji' => ($fTime + $fCCTime),
                                'sredni czas generacji' => (Db::$Shop->sqlOne($sQuerySelect, array(Router::$sFullAdress)))
                            ), TRUE
                        )
                    )
                .'</pre>'
                .'</div>'."\r\n";

            echo $sDebug;
        }
        
        Db::$Shop->saveQueriesLog();
        Db::$Forum->saveQueriesLog();
        
        Error::show();
    }
    
    
    /*
    // Metody prywatne, protected
    */

    
    private function _loadConfig()
    {
        $sPath = dirname(__FILE__).'/';
        
        self::loadClass('Config', $sPath);
        Config::setConfig();
    }
    
    private function _loadCore()
    {
        self::loadClass('Autoloader');
        
        new Autoloader();
    }
    
    private function _loadMVC()
    {
        self::loadClass('Model', Config::RealPath.Config::FOLDER_Site.Config::FOLDER_EngineMVC);
        self::loadClass('Controller', Config::RealPath.Config::FOLDER_Site.Config::FOLDER_EngineMVC);
    }

    private function _saveStats($p_fTime = 0.00000)
    {
        if (Config::STAT_Create === TRUE && isset($_SERVER['REMOTE_ADDR']) && strpos(Config::STAT_NoStatHosts, $_SERVER['REMOTE_ADDR']) === FALSE)
        {
            // zapis logu w postaci:
            // data | unixtime | adres hosta | adres strony | czas generacji | adres poprzedni | url | przegladarka
            $sFileName = 'access_'.date("Ymd", time()).'.log';
            $sMessage = date("Y/m/d H:i:s", time())."\t".$p_fTime."\t".$_SERVER['REMOTE_ADDR']."\t".Router::$sFullAdress."\t".((isset($_SERVER['HTTP_REFERER'])) ? $_SERVER['HTTP_REFERER'] : '')."\t".$_SERVER['REQUEST_URI']."\t".((isset($_SERVER['HTTP_USER_AGENT'])) ? $_SERVER['HTTP_USER_AGENT'] : '')."\r\n";
            
            if (!file_exists(Config::RealPath.Config::FOLDER_Tmp.Config::STAT_Path.$sFileName))
            {
                Lib::stout($sFileName, Config::RealPath.Config::FOLDER_Tmp.Config::STAT_Path, "ACCESS :: ".date("Y/m/d H:i:s", time())."\r\n", TRUE);
                @chmod(Config::RealPath.Config::FOLDER_Tmp.Config::STAT_Path.$sFileName, 0777);
            }
            
            @error_log($sMessage, 3, Config::RealPath.Config::FOLDER_Tmp.Config::STAT_Path.$sFileName);
            @chmod(Config::RealPath.Config::FOLDER_Tmp.Config::STAT_Path.$sFileName, 0777);
        }
    }

    private function _initWWW()
    {
        new Router();
        Form::singleton();            // obsluga formularzy i _POST
        Customer::singleton();        // obsluga klienta
        $this->_loadMVC();            // ladujemy podstawowe klasy kontrolera i modelu
        $this->_initMVC();            // ladujemy kontroler widoku i widok z elementami
    }
    
    private function _initMVC()
    {
        if (strlen(Router::$aTemplateData['engine_controller']) > 0)
        {
            $sViewObject = '';

            $sControllerObject = Router::$aTemplateData['engine_controller'].'Controller';

            if (strlen(Router::$aTemplateData['engine_view']) > 0)
            {
                $sViewObject = Router::$aTemplateData['engine_view'].'View';
            }

            new $sControllerObject(Router::$aTemplateData['controller_action'], $sViewObject);
        }
    }
    
    private function _initCron()
    {
        new Router(TRUE);             // obsluga adresu
        Router::forceFullAddress();   // wymuszamy zawsze pelne adresy
        $this->_loadMVC();            // ladujemy podstawowe klasy kontrolera i modelu
    }
    
    
    /*
    // Metody publiczne
    */


    public static function setClassLoaded($p_sClassName)
    {
        $sClassName = trim((string)($p_sClassName));

        if (strlen($sClassName) > 0)
        {
            self::$_aLoadedClasses[$sClassName] = $sClassName;
        }
    }

    public static function getClassLoaded($p_sClassName)
    {
        $sClassName = trim((string)($p_sClassName));

        if (strlen($sClassName) > 0 && isset(self::$_aLoadedClasses[$sClassName]))
        {
            return (self::$_aLoadedClasses[$sClassName]);
        }

        return FALSE;
    }

    public static function loadClass($p_sClassName, $p_sPath = NULL)
    {
        $sClassName = trim((string)($p_sClassName));

        if (strlen($sClassName) > 0)
        {
            $sPath = trim((isset($p_sPath) && $p_sPath != NULL) ? ((string)($p_sPath)) : Config::RealPath.Config::FOLDER_Site.Config::FOLDER_EngineLibs);

            $sClassFilePath = strtolower($sPath.$sClassName.'.class.php');

            try
            {
                require_once($sClassFilePath);
            }
            catch (Exception $e)
            {
                die('Error class '.$sClassFilePath.' is missing');
                
                die();
            }
            
            self::setClassLoaded($sClassName);
            return TRUE;
        }
        else
        {
            if (class_exists('Error'))
            {
                Error::save('f101', 'No class name', __FILE__, __LINE__);
            }
            else
            {
                die('Error class missing');
            }
        }

        return FALSE;
    }

    public static function loadElement($p_sElementName)
    {
        self::$_aLoadedElements[$p_sElementName] = $p_sElementName;
    }
}
?>
