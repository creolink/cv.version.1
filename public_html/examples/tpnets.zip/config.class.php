<?php
/**
 *
 * Klasa konfiguracji programu
 *
 * @author Jakub Luczynski jakub.luczynski@gmail.com
 *
 * @version 2.0
 * @copyright (c) 2012 - 2013 CreoLink, http://www.creolink.pl/
 *
 */
?>
<?php
require_once ("config/ConfigRuntime.php");

class Config extends ConfigRuntime
{
    /*
    // Deklaracje pol klasy
    */
    
    
    public static $aCfg = array();              // tablica zmiennych konfiguracyjnych
    public static $sBaseAddress;                // aktualna domena
    public static $sSessionCookieDomain;        // aktualna domena dla ciastek i sesji
    public static $sServerProtocol;             // aktualny protokol serwera
    public static $aNoStatHosts;                // tablica hostow lub adresow ip, z ktorych nie zapisujemy statow

    public static $sPortalCode;                 // kod portalu, w ktorym aktualnie przebywamy
    public static $aPortalToAddress;            // lista adresow dla kodow portali

    public static $sGACode;                    // kod google analytics dla aktualnego portalu
    public static $sGMap;                      // kod google maps dla aktualnego portalu

    public static $sLangCode;                  // kod jezyka
    public static $iLangId;                    // id jezyka (pobierany w Dictionary::_getLangId)
    public static $sLangAddress;               // address dla jezyka
    
    
    /*
    // Metody prywatne, protected
    */
    
    
    private static function _setBaseAddress()
    {
        $aTmpBaseAddresses = &self::$aCfg['BaseAddresses'];
        $aTmpBaseAddresses = explode("|", self::BASE_Addresses);
        
        $sServerName = str_replace("www.", '', ((isset($_SERVER['HTTP_HOST'])) ? $_SERVER['HTTP_HOST'] : $aTmpBaseAddresses[0]));
        
        self::$sLangCode = ((preg_match("~^([a-zA-Z]{2})[\.]~", $sServerName, $aLangCodes)) ? trim($aLangCodes[1]) : 'pl');
        self::$sLangAddress = ((self::$sLangCode == 'pl') ? '' : self::$sLangCode.'.');

        $sServerName = str_replace(self::$sLangAddress, '', $sServerName);

        // ustawiamy adres bazowy
        $iPortalIndex = (array_search($sServerName, $aTmpBaseAddresses) ?: 0);
        self::$sBaseAddress = ((self::BASE_WWW) ? 'www.' : '').self::$sLangAddress.$aTmpBaseAddresses[$iPortalIndex];

        // ustawiamy kod portalu
        $aTmpPortalCodes = &self::$aCfg['PortalCodes'];
        $aTmpPortalCodes = explode("|", self::BASE_Codes);
        self::$sPortalCode = (isset($aTmpPortalCodes[$iPortalIndex]) ? $aTmpPortalCodes[$iPortalIndex] : '');

        // ustawiamy adresy portali wzgledem kodow
        if (is_array($aTmpPortalCodes))
        {
            foreach($aTmpPortalCodes as $iIndex => $sPortalCode)
            {
                self::$aPortalToAddress[$sPortalCode] = $aTmpBaseAddresses[$iIndex];
            }
        }

        // ustawiamy parametry dla narzedzi google
        $aTmpGoogle = &self::$aCfg['GACodes'];
        $aTmpGoogle = explode("|", self::GOOGLE_AnalyticsCodes);
        self::$sGACode = (isset($aTmpGoogle[$iPortalIndex]) ? $aTmpGoogle[$iPortalIndex] : '');

        $aTmpGoogle = &self::$aCfg['GMaps'];
        $aTmpGoogle = explode("|", self::GOOGLE_MapCodes);
        self::$sGMap = (isset($aTmpGoogle[$iPortalIndex]) ? $aTmpGoogle[$iPortalIndex] : '');
    }
    
    private static function _setCookieDomain()
    {
        $aTmp = &self::$aCfg['SessionCookieDomains'];
        $aTmp = explode("|", self::SessionCookieDomains);
        $iIndex = 0;

        if (is_array($aTmp))
        {
            foreach($aTmp as $iIdx => $sDomain)
            {
                if (strpos(self::$sBaseAddress, $sDomain) !== FALSE)
                {
                    $iIndex = $iIdx; break;
                }
            }
        }
        
        self::$sSessionCookieDomain = $aTmp[$iIndex];
    }

    private static function _setProtocol()
    {
        self::$sServerProtocol = self::Protocol;

        if ((isset($_SERVER['SERVER_PROTOCOL']) && strpos('HTTPS', $_SERVER['SERVER_PROTOCOL']) !== FALSE) || (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443))
        {
            self::$sServerProtocol = self::SSL_Protocol;
        }
    }

    
    /*
    // Metody publiczne
    */
    
    
    public static function setConfig()
    {
        self::_setProtocol();
        self::_setBaseAddress();
        self::_setCookieDomain();
        self::setPHPConfig();
        
        $aCfg = &self::$aCfg;
        
        //$aCfg = get_class_vars(__CLASS__);
        
        $aCfg['BaseAddress']                    = self::$sBaseAddress;
        
        $aCfg['session.use_trans_sid']          = ini_get('session.use_trans_sid');
        $aCfg['session.use_cookies']            = ini_get('session.use_cookies');
        $aCfg['session.use_only_cookies']       = ini_get('session.use_only_cookies');
        $aCfg['session.hash_function']          = ini_get('session.hash_function');
        $aCfg['session.cookie_lifetime']        = ini_get('session.cookie_lifetime');
        $aCfg['session.cookie_domain']          = ini_get('session.cookie_domain');
        $aCfg['session.cookie_path']            = ini_get('session.cookie_path');
        $aCfg['session.cache_limiter']          = ini_get('session.cache_limiter');
        $aCfg['session.save_handler']           = ini_get('session.save_handler');
        
        $aCfg['default_mimetype']               = ini_get('default_mimetype');
        $aCfg['default_charset']                = ini_get('default_charset');
        
        $aCfg['error_reporting']                = ini_get('error_reporting');
        $aCfg['display_errors']                 = ini_get('display_errors');
        
        $aCfg['date.timezone']                  = ini_get('date.timezone');
        
        $aCfg['magic_quotes_gpc']               = ini_get('magic_quotes_gpc');
        $aCfg['allow_call_time_pass_reference'] = ini_get('allow_call_time_pass_reference');
        $aCfg['memory_limit']                   = ini_get('memory_limit');
    }
    
    public static function setPHPConfig()
    {
        // sesja
        ini_set('session.use_trans_sid', self::SessionUseTransSid);
        ini_set('session.use_cookies', self::SessionUseCookies);
        ini_set('session.use_only_cookies', self::SessionUseOnlyCookies);
        ini_set('session.hash_function', self::SessionHashFunction);
        ini_set('session.cookie_lifetime', self::SessionLifeTime);
        ini_set('session.cookie_path', self::SessionCookiePath);
        ini_set('session.cache_limiter', self::SessionCacheLimiter);
        ini_set('session.cookie_domain', self::$sSessionCookieDomain);
        ini_set('session.save_handler', self::SessionSaveHandler);
        ini_set('session.gc_probability', 0);
        ini_set('session.gc_divisor', 0);
        ini_set('session.gc_maxlifetime', self::SessionLifeTime);
        
        // mime, kodownie
        ini_set('default_mimetype', self::DefaultMimetype);
        ini_set('default_charset', self::DefaultCharset);
        
        // bledy
        ini_set('error_reporting', self::ErrorReporting);
        ini_set('display_errors', self::DisplayErrors);
        
        // strefa czasowa
        ini_set('date.timezone', self::Timezone);
        if (function_exists('date_default_timezone_set')) { date_default_timezone_set(self::Timezone); }
        
        // inne zmienne
        ini_set('magic_quotes_gpc', self::MagicQuotesGpc);
        ini_set('allow_call_time_pass_reference', self::AllowCallTimePassReference);
                
        // kodowanie w funkcjach tekstowych
        mb_internal_encoding(Config::DefaultCharset);
        
        // ustawienie lokalnych danych
        setlocale(LC_ALL, Config::Locale);
        setlocale(LC_NUMERIC, 'C');
    }
}
?>
