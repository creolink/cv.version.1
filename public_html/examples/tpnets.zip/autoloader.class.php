<?php
/**
 *
 * Autoloader - autoloader dla klas
 *
 * @author Jakub Luczynski jakub.luczynski@gmail.com
 *
 * @version 2.0
 * @copyright (c) 2012 - 2013 CreoLink, http://www.creolink.pl/
 *
 */
?>
<?php
class Autoloader
{
    /*
    // Deklaracje pol klasy
    */





    /*
    // Konstruktor i destruktor
    */


    public function __construct()
    {
        spl_autoload_register(array($this, 'element'));
        spl_autoload_register(array($this, 'model'));
        spl_autoload_register(array($this, 'view'));
        spl_autoload_register(array($this, 'controller'));

        spl_autoload_register(array($this, 'library'));
    }

    public function __destruct() {}


    /*
    // Metody prywatne, protected
    */





    /*
    // Metody publiczne
    */


    public function library($p_sClass)
    {
        if (!Engine::getClassLoaded($p_sClass))
        {
            $sClass = strtolower($p_sClass);
            
            set_include_path(Config::RealPath.Config::FOLDER_Site.Config::FOLDER_EngineLibs);
            spl_autoload_extensions('.class.php');

            spl_autoload($sClass);

            Engine::setClassLoaded($p_sClass);
        }
    }

    public function mvc($p_sClass)
    {
        if (!Engine::getClassLoaded($p_sClass))
        {
            $sClass = strtolower($p_sClass);
            
            set_include_path(Config::RealPath.Config::FOLDER_Site.Config::FOLDER_EngineMVC);
            spl_autoload_extensions('.class.php');

            spl_autoload($sClass);

            Engine::setClassLoaded($p_sClass);
        }
    }

    public function controller($p_sClass)
    {
        if (strpos($p_sClass, 'Controller') !== FALSE)
        {
            $sClass = str_replace('Controller', '', $p_sClass);
            
            $sClass = strtolower($sClass);

            set_include_path(Config::RealPath.Config::FOLDER_Site.Config::FOLDER_EngineControllers);
            spl_autoload_extensions('.controller.class.php');

            spl_autoload($sClass);

            Engine::setClassLoaded($p_sClass);
        }
    }

    public function model($p_sClass)
    {
        if (strpos($p_sClass, 'Model') !== FALSE)
        {
            $sClass = str_replace('Model', '', $p_sClass);
            
            $sClass = strtolower($sClass);
            
            set_include_path(Config::RealPath.Config::FOLDER_Site.Config::FOLDER_EngineModels);
            spl_autoload_extensions('.model.class.php');

            spl_autoload($sClass);

            Engine::setClassLoaded($p_sClass);
        }
    }

    public function element($p_sClass)
    {
        if (strpos($p_sClass, 'Element') !== FALSE)
        {
            $sClass = str_replace('Element', '', $p_sClass);
            
            $sClass = strtolower($sClass);

            set_include_path(Config::RealPath.Config::FOLDER_Site.Config::FOLDER_EngineElements);
            spl_autoload_extensions('.element.class.php');

            spl_autoload($sClass);

            Engine::setClassLoaded($p_sClass);
        }
    }

    public function view($p_sClass)
    {
        if (strpos($p_sClass, 'View') !== FALSE)
        {
            $sClass = str_replace('View', '', $p_sClass);
            
            $sClass = strtolower($sClass);

            set_include_path(Config::RealPath.Config::FOLDER_Site.Config::FOLDER_EngineViews);
            spl_autoload_extensions('.view.class.php');

            spl_autoload($sClass);

            Engine::setClassLoaded($p_sClass);
        }
    }
    
}
?>
