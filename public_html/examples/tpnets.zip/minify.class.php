<?php
/**
 *
 * minify - model obslugujacy zminimalizowane css i js, czyli zmniejszanie ilosci pobieranych plikow css i js w naglowkach strony
 *
 * @author Jakub Luczynski jakub.luczynski@gmail.com
 *
 * @version 2.0
 * @copyright (c) 2012 - 2013 CreoLink, http://www.creolink.pl/
 *
 */
?>
<?php
class Minify extends Singleton
{
    /*
    // Deklaracje pol klasy
    */


    private $_aSrcFiles = array();                // lista plikow do zminimalizowania
    private $_sFileName = '';                     // nazwa pliku wynikowego
    private $_sFileType = '';                     // typ pliku
    private $_aFileData = array();                // dane pliku wynikowego
    private $_aEncodeMethod = array('','');       // metoda pakowania
    private $_iCompressionLevel = 6;              // poziom kompresji
    private $_iLastChangeTime = 0;                // czas ostatniej zmiany plikow
    
    private $_sExt = '';                          // rozszerzenie plikow zrodlowych
    private $_sCachePath = '';                    // sciezka zapisywania cache-owanych plikow


    /*
    // Konstruktor i destruktor
    */





    /*
    // Metody prywatne, protected
    */


    private function _isBuggyIe()
    {
        $sUserAgent = $_SERVER['HTTP_USER_AGENT'];

        if (strpos($sUserAgent, 'Mozilla/4.0 (compatible; MSIE ') !== FALSE || strpos($sUserAgent, 'Opera') !== FALSE)
        {
            return FALSE;
        }

        $fVersion = ((float)(substr($sUserAgent, 30)));

        return ($fVersion < 6 || ($fVersion == 6 && strpos($sUserAgent, 'SV1') === FALSE));
    }

    private function _getEncoding()
    {
        // @link http://www.w3.org/Protocols/rfc2616/rfc2616-sec14.html

        // sprawdzamy ie6
        if (!isset($_SERVER['HTTP_ACCEPT_ENCODING']) || $this->_isBuggyIe())
        {
            $this->_aEncodeMethod = array('', '');
        }

        $sAcceptEncoding = $_SERVER['HTTP_ACCEPT_ENCODING'];

        // sprawdzamy gzip (szybkie) - wiekszosc przegladarek || opera
        if (strpos($sAcceptEncoding, 'gzip,') === 0 || strpos($sAcceptEncoding, 'deflate, gzip,') === 0)
        {
            $this->_aEncodeMethod = array('gzip', 'gzip');
        }

        // sprawdzamy gzip (wolne) - pozostale przegladarki
        if (preg_match('@(?:^|,)\\s*((?:x-)?gzip)\\s*(?:$|,|;\\s*q=(?:0\\.|1))@', $sAcceptEncoding, $aAcceptMethod))
        {
            $this->_aEncodeMethod = array('gzip', $aAcceptMethod[1]);
        }

        // sprawdzamy deflate
        $sAcceptEncodingRev = strrev($sAcceptEncoding);
        
        if (strpos($sAcceptEncodingRev, 'etalfed ,') === 0                                        // ie, webkit
            || strpos($sAcceptEncodingRev, 'etalfed,') === 0                                      // gecko
            || strpos($sAcceptEncoding, 'deflate,') === 0                                         // opera
            || preg_match('@(?:^|,)\\s*deflate\\s*(?:$|,|;\\s*q=(?:0\\.|1))@', $sAcceptEncoding)
            )
        {
            $this->_aEncodeMethod = array('deflate', 'deflate');
        }

        //sprawdzamy compress
        if (preg_match('@(?:^|,)\\s*((?:x-)?compress)\\s*(?:$|,|;\\s*q=(?:0\\.|1))@', $sAcceptEncoding, $aAcceptMethod))
        {
            $this->_aEncodeMethod = array('compress', $aAcceptMethod[1]);
        }
    }

    private function _packStream()
    {
        $this->_aFileData['Headers']['Vary'] = 'Accept-Encoding';
        
        // pakujemy jesli przegladarka obsluguje pakowane pliki
        if ($this->_aEncodeMethod[0] !== '' && extension_loaded('zlib'))
        {
            switch($this->_aEncodeMethod[0])
            {
                case 'deflate':
                    $sStreamEncoded = gzdeflate($this->_aFileData['Stream'], $this->_iCompressionLevel);
                    break;

                case 'gzip':
                    $sStreamEncoded = gzencode($this->_aFileData['Stream'], $this->_iCompressionLevel);
                    break;

                default:
                    $sStreamEncoded = gzcompress($this->_aFileData['Stream'], $this->_iCompressionLevel);
                    break;
            }

            if ($sStreamEncoded !== FALSE)
            {
                $this->_aFileData['Headers']['Content-Encoding'] = $this->_aEncodeMethod[1];
                $this->_aFileData['Stream'] = $sStreamEncoded;
            }
        }
    }
    
    private function _minifyData()
    {
        switch($this->_sFileType)
        {
            case Config::CACHE_MinJs: // sciezka do pojedynczych plikow js
                $this->_aFileData['Stream'] = JSMin::minify($this->_aFileData['Stream']);
                break;

            case Config::CACHE_MinCss: // sciezka do pojedynczych plikow css
                $this->_aFileData['Stream'] = CssMin::minify($this->_aFileData['Stream']);
                break;
        }
    }
    
    private function _createFile()
    {
        // sprawdzamy i scalamy zawartosci plikow w jeden
        // usuwamy wszystkie komentarze

        $sSrcFilePath = ''; $aOptions = array();

        switch($this->_sFileType)
        {
            case Config::CACHE_MinJs: // sciezka do pojedynczych plikow js
            //case 'js':
                $sSrcFilePath = Config::FOLDER_EngineJS;
                $sHeaderContentType = Lib::getMimeContentType('js'); //'application/x-javascript';
                $aOptions = array(
                    'NONEWLINES' => FALSE,
                    'NOCOMMENTS' => FALSE,
                    'NOSPACES' => FALSE
                );
                $this->_sCachePath = Config::CACHE_TmpMinJs;
                $this->_sExt = 'js';
                break;

            case Config::CACHE_MinCss: // sciezka do pojedynczych plikow css
            //case 'css':
                $sSrcFilePath = Config::FOLDER_EngineCSS;
                $sHeaderContentType = Lib::getMimeContentType('css');
                $aOptions = array(
                    'INSERTNEWLINE' => '}',
                    'SIGNTAB' => '',
                    'SIGNNEWLINE' => ''
                );
                $this->_sCachePath = Config::CACHE_TmpMinCss;
                $this->_sExt = 'css';
                break;
        }

        if ($sSrcFilePath != '' && is_array($this->_aSrcFiles) && sizeof($this->_aSrcFiles) > 0)
        {
            // sprawdzamy czasy zmiany plikow - jesli sa zmienione, zmieniamy cache
            foreach ($this->_aSrcFiles as $iIdx => $sSrcFileName)
            {
                $sFile = $sSrcFilePath.$sSrcFileName.'.'.$this->_sExt;
                if (!file_exists($sFile)) { continue; }
                $this->_iLastChangeTime = ((($iFileTime = filemtime($sFile)) > $this->_iLastChangeTime) ? $iFileTime : $this->_iLastChangeTime);
            }

            // sprawdzamy czy taki plik juz istnieje w cache / na dysku - jesli tak, pobieramy z cache
            // sprawdzamy tez date ostatniej zmiany plikow, jesli jest nowsza, tworzymy nowy plik
            $iLastChangeTime = Cache::get($this->_sFileType.'ChangeTime,'.md5($this->_sFileName), TRUE);
            $sCacheKey = $this->_sFileName.'.'.$this->_sFileType.(($this->_aEncodeMethod[1] != '') ? '.'.$this->_aEncodeMethod[1] : 'none');
            if ($iLastChangeTime < $this->_iLastChangeTime || !($this->_aFileData = Cache::get($sCacheKey, TRUE)))
            {
                $this->_aFileData['Stream'] = '';
                
                foreach ($this->_aSrcFiles as $iIdx => $sSrcFileName)
                {
                    $sFile = $sSrcFilePath.$sSrcFileName.'.'.$this->_sExt;
                    if (!file_exists($sFile)) { continue; }
                    $this->_aFileData['Stream'] .= file_get_contents($sFile).' '."\r\n";
                }
                
                // dodajemy czas generacji pliku
                $this->_aFileData['Stream'] .= "\r\n".'/'.'* wygenerowano w '.Timer::display().' *'.'/';
                
                $this->_aFileData['Type'] = $this->_sFileType;
                $this->_aFileData['Name'] = $this->_sFileName;

                $this->_aFileData['Headers']['Content-Type'] = $sHeaderContentType;
                
                //zapisujemy plik na dysku
                $this->saveFile();

                $this->_packStream();

                $this->_aFileData['Headers']['Content-Length'] = strlen($this->_aFileData['Stream']);

                $this->_aFileData['Headers']['Expires'] = gmdate('D, d M Y H:i:s \G\M\T', (time() + (24 * 3600)));

                Cache::add($sCacheKey, $this->_aFileData, (24 * 3600), TRUE);
                Cache::set($this->_sFileType.'ChangeTime,'.md5($this->_sFileName), $this->_iLastChangeTime, (24 * 3600), TRUE);
            }
        }
    }
    
    private function saveFile()
    {
        if (Config::CACHE_SaveMinified == TRUE)
        {
            $sDir = $this->_sCachePath;
            if (!is_dir($sDir))
            {
                mkdir($sDir, 0777, TRUE);
            }
            
            $sFile = $sDir.$this->_sFileName.'.'.$this->_sFileType;
            
            if (!file_exists($sFile))
            {
                $this->_minifyData();
                
                $fp = fopen($sFile, 'wb+');
                fwrite($fp, $this->_aFileData['Stream'], strlen($this->_aFileData['Stream']));
                fclose($fp);
            }
        }
    }


    /*
    // Metody publiczne
    */


    public function getFile()
    {
        // pobieramy liste plikow do scalenia na podstawie adresu
        preg_match('~^(.+/)*(.*)\..*('.Config::CACHE_MinCss.'|'.Config::CACHE_MinJs.')$~isx', Router::$aAddress[1], $aRequest);
        
        // ustawiamy typ i nazwe pliku w wartosciach zmiennych
        $this->_sFileName = $aRequest[2];
        $this->_sFileType = $aRequest[3];
        
        // lista plikow do pobrania i zlaczenia w jeden string
        $this->_aSrcFiles = explode(',', $this->_sFileName);
        
        // sprawdzamy jaka metode obsluguje przegladarka
        $this->_getEncoding();
        
        // pobieramy plik
        $this->_createFile();

        // zwracamy plik do wyswietlenia
        return ((isset($this->_aFileData['Stream'])) ? $this->_aFileData : array('Stream' => ''));
    }
    
    public function getStream(array $p_aFiles, $p_sType = 'css')
    {
        $aFiles = ((array)($p_aFiles));
        $sType = trim((string)($p_sType));
        
        $this->_sFileName = implode(',', $aFiles);
        $this->_sFileType = $sType;
        
        $this->_aSrcFiles = $aFiles;
        
        $this->_createFile();
        
        return ((isset($this->_aFileData['Stream'])) ? $this->_aFileData['Stream'] : array('Stream' => ''));
    }
}
?>
