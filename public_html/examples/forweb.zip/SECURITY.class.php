<?

class SECURITY
{
    var $DB;                // database object
    var $SESSION;           // session object
    var $ADMIN;             // admin session object
    var $CONFIG;            // config object
    var $ADDRESS;           // address object
    var $TIMER;             // timer object
    var $PROJECT;           // project object
    
    function SECURITY($_pOBJECTSArray)
    {
        $this->OBJECTSArray = &$_pOBJECTSArray;
        foreach($_pOBJECTSArray as $idx => $row)
        {
            $this->{$idx} = &$_pOBJECTSArray[$idx];
        }
        unset($_pOBJECTSArray);
    }
    
    function CheckRemoteIp()
    {
        if ($this->PROJECT->_sesEbokTemplate) { return TRUE; }
        
        if ($this->DB->SQLOne("SELECT keyvalue FROM mmssafe WHERE keyname='ACTIVE'"))
        {
            $ipaddress=$_SERVER['REMOTE_ADDR'];
            if ($iplist=$this->DB->SQLCol("SELECT keyvalue FROM mmssafe WHERE keyname='IP'"))
            {
                $b=explode(".", $ipaddress);
                foreach($iplist as $idx => $row)
                {
                    if ($ipaddress==$row) { return TRUE; break; }
                    $a=explode(".", $row);
                    if ($a[0]==$b[0])
                    {
                        if ($a[1] && $a[1]==$b[1])
                        {
                            if ($a[2] && $a[2]==$b[2])
                            {
                                if ($a[3] && $a[3]==$b[3])
                                {
                                    return TRUE;
                                }
                                if (!$a[3]) { return TRUE; }
                            }
                            if (!$a[2]) { return TRUE; }
                        }
                        if (!$a[1]) { return TRUE; }
                    }
                }
            }
            $this->PROJECT->LOGIN->AddLoginHistory(0);
            header("Location: http://".$this->DB->SQLOne("SELECT keyvalue FROM mmssafe WHERE keyname='REDIRECT'")); die();
        }
        return TRUE;
    }
}



?>
