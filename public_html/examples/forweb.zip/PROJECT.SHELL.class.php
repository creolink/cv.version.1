<?

class SHELL
{
    var $DB;                // database object
    var $SESSION;           // session object
    var $ADMIN;             // admin session object
    var $CONFIG;            // config object
    var $ADDRESS;           // address object
    var $TIMER;             // timer object
    var $PROJECT;           // project object
    var $_Sock;
    var $_ShellRes;
    var $_ShellStream;
    var $_Id;
    var $_ShellProcess;
    var $_ShellLogin;
    var $Scripts;
    var $allowed;
    var $_ActualProccessId;
    var $_commandDBId;
    var $_routerId;

  
    function SHELL($_pOBJECTSArray)
    {
        $this->OBJECTSArray = &$_pOBJECTSArray;
        foreach($_pOBJECTSArray as $idx => $row)
        {
            $this->{$idx} = &$_pOBJECTSArray[$idx];
        }
        unset($_pOBJECTSArray);
    }
    
    function GetShellData($routerid)
    {
        @set_time_limit(60); @ignore_user_abort(FALSE);
        if ($routerid)
        {
            if ($data=$this->DB->SQLRow("SELECT inet_ntoa(r.ipaddr) AS Host, ass.user AS User, ass.pass AS Pass, ass.port AS Port, ass.rsapubkey AS RSAPubKey, ass.rsaprivkey RSAPrivKey FROM servers r LEFT JOIN adminsserversshell ass ON ass.serverid=r.id WHERE r.id='".$routerid."' && ass.adminid='".$this->PROJECT->_sesAdminId."'"))
            {
                //rozkodowujemy
                $data['User']=trim($this->HASH->DecodeString(trim($data['User'])));
                $data['Pass']=trim($this->HASH->DecodeString(trim($data['Pass'])));
                
                //tworzymy pliki RSA
                $data['RSAPubKey_PATH']=trim((($this->PROJECT->_BaseDir) ? $this->PROJECT->_BaseDir : '').$this->CONFIG->GetConfigValue('FilesFolder').'tmpFiles/'.session_id().'.pub');
                $data['RSAPrivKey_PATH']=trim((($this->PROJECT->_BaseDir) ? $this->PROJECT->_BaseDir : '').$this->CONFIG->GetConfigValue('FilesFolder').'tmpFiles/'.session_id());

                @unlink($ShellData['RSAPubKey_PATH']);
                @unlink($ShellData['RSAPrivKey_PATH']);

                $data['RSAPubKey']=trim($this->HASH->DecodeString(trim($data['RSAPubKey'])));
                $data['RSAPrivKey']=trim($this->HASH->DecodeString(trim($data['RSAPrivKey'])));
                
                if ($data['RSAPubKey'])
                {
                    $fp=fopen($data['RSAPubKey_PATH'], 'wb+');
                    fputs($fp, $data['RSAPubKey'], strlen($data['RSAPubKey']));
                    fclose($fp);
                }
                
                if ($data['RSAPrivKey'])
                {
                    $fp=fopen($data['RSAPrivKey_PATH'], 'wb+');
                    fputs($fp, $data['RSAPrivKey'], strlen($data['RSAPrivKey']));
                    fclose($fp);
                }
                
                $this->_routerId=$routerid;
                
                return ($data);
            }
        }
        return FALSE;
    }
    
    function Connect($ShellData, $show=TRUE, $connectOnly=FALSE)
    {
        @set_time_limit(60); @ignore_user_abort(FALSE);
        if ($ShellData)
        {
            if ($show) { echo 'Connecting to Host: '.$ShellData['Host'].', Port: '.$ShellData['Port'].'... please wait...'.(($connectOnly) ? "\r\n" : '<br>'); }
            if ($show) { flush(); ob_flush(); }
            $connected=FALSE;
            $methods=array    (
                                "kex" => "diffie-hellman-group-exchange-sha1",
                                "hostkey" => "ssh-rsa",
                                "client_to_server" => array (
                                                                "crypt" => "aes256-cbc",
                                                                "mac" => "hmac-sha1",
                                                                "comp" => "none"
                                                            ),
                                "server_to_client" => array (
                                                                "crypt" => "aes256-cbc",
                                                                "mac" => "hmac-sha1",
                                                                "comp" => "none"
                                                            )
                                
                            );
            
            $callback=array("debug" => "my_debug");
            
            if (!@function_exists('ssh2_connect'))
            {
                die('BRAK BIBLIOTEKI SSH2 dla PHP. Skontaktuj si� z biurem Forweb.');
            }
                        
            if ($socket=@ssh2_connect($ShellData['Host'], $ShellData['Port'], $methods, $callback))
            {
                $fingerprint = ssh2_fingerprint($socket, SSH2_FINGERPRINT_MD5 | SSH2_FINGERPRINT_HEX);
                if ($show) { echo 'MD5 server SSH FingerPrint: '.(ssh2_fingerprint($socket)).(($connectOnly) ? "\r\n" : '<br>'); }

                if ($ShellData['RSAPubKey'] && $ShellData['RSAPrivKey'] && @ssh2_auth_pubkey_file($socket, $ShellData['User'], $ShellData['RSAPubKey_PATH'], $ShellData['RSAPrivKey_PATH']))
                {
                    $connected=TRUE;
                }
                else
                if (@ssh2_auth_password($socket, $ShellData['User'], $ShellData['Pass']))
                {
                    $connected=TRUE;
                }
                @unlink($ShellData['RSAPubKey_PATH']);
                @unlink($ShellData['RSAPrivKey_PATH']);
                
                if ($connected)
                {
                    if (!$connectOnly)
                    {
                        $this->_ShellLogin=$ShellData['User'];
                        $this->_Sock=$socket;
                    }

                    if ($show) { echo 'Connected to Host: '.$ShellData['Host'].', Port: '.$ShellData['Port'].(($connectOnly) ? "\r\n" : '<br>'); }
                    if ($show) { flush(); ob_flush(); }
                    return TRUE;
                }
                else
                {
                    if ($show)
                    {
                        echo date("d/m/Y H:i:s", time()).': NIEPRAWID�OWA AUTORYZACJA (z�y u�ytkownik lub has�o)'.(($connectOnly) ? "\r\n" : '<br>');
                        print_r(ssh2_auth_none($socket, $ShellData['User'])).(($connectOnly) ? "\r\n" : '<br>');
                        print_r(ssh2_methods_negotiated($socket)).(($connectOnly) ? "\r\n" : '<br>');
                        flush(); ob_flush();
                    }
                }
            }
            else
            {
                echo date("d/m/Y H:i:s", time()).': BRAK PO��CZENIA Z SERWEREM '.$ShellData['Host'].(($connectOnly) ? "\r\n" : '<br>');
                if ($show) { flush(); ob_flush(); }
            }
        }
        return FALSE;
    }
    
    function _Set_Timeout(&$resource, $s,$m=0)
    {
        @set_time_limit(60); @ignore_user_abort(FALSE);
        if (version_compare(phpversion(),'4.3.0','<'))
        {
            return socket_set_timeout($resource,$s,$m);
        }
        return stream_set_timeout($resource,$s,$m);
    }
    
    function _InitShell()
    {
        @set_time_limit(60); @ignore_user_abort(FALSE);

        if (!($this->_ShellRes=@ssh2_shell($this->_Sock,'ansi'))) //,'xterm'
        {
            echo 'NIE MO�NA UTWORZY� PROCESU SHELLA<br>';
            return FALSE;
        }
        return TRUE;
    }
    
    function _MaxProcessId($processList)
    {
        @set_time_limit(60); @ignore_user_abort(FALSE);
        $max=0;
        if ($a=explode("\n", $processList))
        {
            foreach($a as $idx => $row)
            {
                $b=preg_replace("/\s+/isx", " ", $row);
                $c=explode(" ",$b);
                $max=(($max<$c[1]) ? $c[1] : $max);
            }
            return ($max);
        }
    }
    
    function _LastProcess($processList, $data, $cmd, $maxprocess, $show=TRUE, $actualprocessList)
    {
        @set_time_limit(60); @ignore_user_abort(FALSE);
        $ConsoleId=$this->ADDRESS->AddressId;
        
        if ($a=explode("\n", $processList))
        {
            foreach($a as $idx => $row)
            {
                $row=htmlspecialchars($row);
                $b=preg_replace("/\s+/isx", " ", $row);
                
                $c=explode(" ",$b);

                if (!in_array($c[1],$actualprocessList,TRUE))
                {
                    $d=preg_replace("/\s+/isx", "[ ]", $cmd);

                    $regexp="/".$d.".*?/isx";
                    
                    if (preg_match($regexp, $row) && !preg_match("/grep/isx", $b))
                    {
                        $this->_ActualProccessId[]=$c[1];
                        if ($show) { echo 'ID Konsoli: '.$ConsoleId.', ID Procesu: '.$c[1].'<br>'; }
                    }
                }
            }

            $this->SESSION->AddSessionValue('Console_'.$ConsoleId, $this->_ActualProccessId);
            return TRUE;
        }
    }
    
    function _GetProcessList($cmd, $show=TRUE)
    {
        @set_time_limit(60); @ignore_user_abort(FALSE);
        if ($this->_Sock)
        {
            if ($cmd) { $command="ps ux | grep '".$cmd."'"; } else { $command='ps ux'; }
            $this->_ShellProcess=@ssh2_exec($this->_Sock, $command."\n");
            if ($this->_ShellProcess)
            {
                @stream_set_blocking($this->_ShellProcess, true);
                
                $j=0; $jj=0; $processList='';
                if ($show) { echo $command.'<br>'; }
                if ($show) { echo '<pre>'; }

                while(!feof($this->_ShellProcess))
                {
                    $result=fread($this->_ShellProcess,1024);

                    if ($show) { echo htmlspecialchars($result); }
                    if (trim($result)=='') { $j++; }
                    if ($j>10 || $jj>500) { break; }

                    if ($show) { flush(); ob_flush(); }
                    $processList.=$result;
                }
                if ($show) { echo '</pre><br>'; }
                
                return ($processList);
            }
            else
            {
                echo 'ERROR: NIE MO�NA URUCHOMI� PROCESU, PRAWDOPODOBNIE ZBYT DU�O OTWARTYCH PO��CZE�';
            }
        }
        return FALSE;
    }
    
    function _GetActualProcessesId($processList, $cmd)
    {
        @set_time_limit(60); @ignore_user_abort(FALSE);
        $actualprocesses=array();
        if ($a=explode("\n", $processList))
        {
            foreach($a as $idx => $row)
            {
                $b=preg_replace("/\s+/isx", " ", $row);
                
                $d=preg_replace("/\s+/isx", "[ ]", $cmd);
                $regexp="/".$d.".*?/isx";
                
                if (!preg_match($regexp, $row) && !preg_match("/grep/isx", $b))
                {
                    $c=explode(" ",$b);
                    $actualprocesses[]=$c[1];
                }
            }
        }
        return ($actualprocesses);
    }

    function _Write($cmd, $show=TRUE, $kill=FALSE)
    {
        @set_time_limit(60); @ignore_user_abort(FALSE);
        if ($this->_ShellStream)
        {
            @fclose($this->_ShellStream);
            unset($this->_ShellStream);
        }
        if ($this->_ShellRes)
        {
            @fclose($this->_ShellRes);
            unset($this->_ShellRes);
        }
        $a=explode(" ",$cmd);
        if (in_array(trim($a[0]),$this->Scripts,true)) { $data=$cmd."\n"; $script=TRUE; }
        else { $data=$cmd."\n"; $script=FALSE; }

        if ($show) { echo date("d/m/Y H:i:s", time()).': '.$data.'<br>'; }

        // Get and increment the packet id
        $id = ++$this->_Id;
        
        if (!$kill)
        {
            $processList=$this->_GetProcessList(NULL, FALSE);

            $actualprocessList=$this->_GetActualProcessesId($processList, 'sshd: '.$this->_ShellLogin.'@notty');
        }

        if ($this->_Sock)
        {
            if ($script)
            {
                if ($this->_InitShell())
                {
                    if (!$kill)
                    {
                        $processList=$this->_GetProcessList('sshd: '.$this->_ShellLogin.'@', $show);
                        $this->_LastProcess($processList, 'sshd: '.$this->_ShellLogin.'@', 'sshd: '.$this->_ShellLogin.'@', $maxprocess, $show, $actualprocessList);
                    }
                    if (!@fwrite($this->_ShellRes,$data."logout\n"))
                    {
                        die('nie mo�na uruchomi� komendy');
                    }
                    @stream_set_blocking($this->_ShellRes, true);
                    $this->_Set_Timeout($this->_ShellRes, 120, 0);
                    $this->_ShellStream=$this->_ShellRes;
                }
            }
            else
            {
                if (!($this->_ShellStream=@ssh2_exec($this->_Sock, $data)))
                {
                    die('nie mo�na uruchomi� komendy');
                }
                if ($kill) { @stream_set_blocking($this->_ShellStream, true); @fclose($this->_ShellStream); }
            }
            if ($this->_ShellStream && !$kill)
            {
                @stream_set_blocking($this->_ShellStream, true);
                $this->_Set_Timeout($this->_ShellStream, 120, 0);

                sleep(1);
                
                if (!$kill)
                {
                    $processList=$this->_GetProcessList($cmd, $show);
                    $this->_LastProcess($processList, $data, $cmd, $maxprocess, $show, $actualprocessList);
                }
            }
        }

        return $id;
    }

    function _PacketRead($show=TRUE)
    {
        @set_time_limit(60); @ignore_user_abort(FALSE);
        if ($this->_ShellStream)
        {
            $j=0; $jj=0;
            if ($show) { echo '<pre style="text-decoration: none;">'; }
            if ($this->_ShellRes)
            {
                while($result=@fgets($this->_ShellRes))
                {
                    @set_time_limit(30);
                    $result=trim($result);
                    if ($show)
                    {
                        echo htmlspecialchars($result).'<br>';

                        //wstawiamy do bazy
                        $this->_WriteDBLog(htmlspecialchars($result));
                    }
                    if (trim($result)=='') { $j++; }
                    if ($j>10 || $jj>500) { break; }

                    
                    if ($show) { flush(); ob_flush(); }
                    if (substr($result,(strlen($result)-6),6)=='logout') { echo 'polecenie wykonane</pre>'; @fclose($this->_ShellRes); $this->KillProcess($this->_ActualProccessId); die(); }
                }

            }
            else
            {
                while(!feof($this->_ShellStream))
                {
                    @set_time_limit(30);
                    $result=fread($this->_ShellStream,4096);

                    if ($show)
                    {
                        echo htmlspecialchars($result);
                        //wstawiamy do bazy
                        $this->_WriteDBLog(htmlspecialchars($result));
                    }
                    if (trim($result)=='') { $j++; }
                    if ($j>10 || $jj>500) { break; }

                    if ($show) { flush(); ob_flush(); }
                }
                @fclose($this->_ShellStream);
            }
            if ($show) { echo '</pre>'; }
        }
        return TRUE;
    }

    function sendCommand($Command, $show=TRUE, $kill=FALSE)
    {
        @set_time_limit(60); @ignore_user_abort(FALSE);
        $Command=trim(preg_replace("/\s+/isx", " ", $Command));

        //wstawiamy do bazy
        $query=    "INSERT INTO ".$this->CONFIG->GetConfigValue('DbLOGS_dbname').".shell_log_commands"
                ." ("
                ."adminid, serverid, senddate, command"
                .")"
                ." VALUES"
                ." ("
                ."'".$this->PROJECT->_sesAdminId."', '".$this->_routerId."', '".time()."', '".$this->HASH->EncodeString($Command)."'"
                .")";
        $this->_commandDBId=$this->DB->SQLInsert($query, $this->CONFIG->GetConfigValue('DbLOGS_dblname'));
        
        return ($this->_Write($Command, $show, $kill));
    }

    function rconCommand($Command, $show=TRUE, $Kill=TRUE, $diescript=TRUE, $kill=FALSE)
    {
        @set_time_limit(60); @ignore_user_abort(FALSE);
        if ($id=$this->sendcommand($Command, $show, $kill))
        {
            if ($show) { $ret = $this->_PacketRead($show); }
        }

        if ($Kill)
        {
            if ($show) { echo '<br>'; }
            $this->KillProcess($this->_ActualProccessId);
            if ($diescript) { die(); }
        }
        return FALSE;
    }
    
    function KillProcess($processId, $killme=TRUE, $html=FALSE)
    {
        @set_time_limit(60); @ignore_user_abort(FALSE);

        if ($processId)
        {
            if (is_array($processId))
            {
                $shellcommand='';
                foreach($processId as $idx => $row)
                {
                    $shellcommand.='kill -9 '.$row.";";
                    echo 'proces ID: '.$row.' zosta� zako�czony; '.(($html) ? '<br>' : "\r\n");
                    flush(); ob_flush();
                }

                $this->rconCommand($shellcommand, FALSE, FALSE, FALSE, TRUE);
                $ConsoleId=$this->ADDRESS->AddressId;
                $this->SESSION->DeleteSessionValue('Console_'.$ConsoleId);
                unset($this->_ActualProccessId);
                if ($killme) { die(); }
                return TRUE;
            }
            else
            {
                $shellcommand='kill -9 '.$processId;
                echo 'proces ID: '.$processId.' zosta� zako�czony'.(($html) ? '<br>' : "\r\n");
                flush(); ob_flush();
                $this->rconCommand($shellcommand, FALSE, FALSE, FALSE, TRUE);
                $ConsoleId=$this->ADDRESS->AddressId;
                $this->SESSION->DeleteSessionValue('Console_'.$ConsoleId);
                unset($this->_ActualProccessId);
                if ($killme) { die(); }
                return TRUE;
            }
        }
        return FALSE;
    }
    
    function _WriteDBLog($data)
    {
        @set_time_limit(60); @ignore_user_abort(FALSE);
        if ($data)
        {
            $query= "INSERT INTO ".$this->CONFIG->GetConfigValue('DbLOGS_dbname').".shell_log_results"
                    ." ("
                    ."shell_log_commands_id, result"
                    .")"
                    ." VALUES"
                    ." ("
                    ."'".$this->_commandDBId."', '".$this->HASH->EncodeString(gzcompress(base64_encode($Command),9))."'"
                    .")";
            $this->DB->SQL($query, $this->CONFIG->GetConfigValue('DbLOGS_dblname'));
        }
        return FALSE;
    }
    
    function GetServersConsoleList()
    {
        $firmid=$this->PROJECT->_sesSelectedFirm;
        $adminid=$this->PROJECT->_sesAdminId;

        $query= "SELECT s.id AS ServerId, CONCAT(s.name, ' ', inet_ntoa(s.ipaddr)) AS ServerName, s.name AS ServerShortName, s.ipaddr AS ServerIP, inet_ntoa(s.ipaddr) AS ServerIpAddress"
                ." FROM servers s"
                ." INNER JOIN adminsserversshell ass ON ass.serverid=s.id"
                ." WHERE 1"
                .(($firmid && !$this->CONFIG->GetConfigValue('Partners_SharedServers')) ? " && s.firmid='".$firmid."'" : "")
                ." && ass.adminid='".$adminid."'"
                ." ORDER BY s.name ASC";
        
        if ($serverslist=$this->DB->SQLAll($query))
        {
            return ($serverslist);
        }
        return FALSE;
    }
    
}
?>
